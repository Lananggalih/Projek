package com.example.tugasbesar_03.view;

public interface MangaClickListener {
    void onClick(boolean position);
}
