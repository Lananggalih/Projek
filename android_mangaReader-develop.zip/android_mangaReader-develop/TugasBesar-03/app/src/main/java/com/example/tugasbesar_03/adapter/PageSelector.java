package com.example.tugasbesar_03.adapter;

public interface PageSelector {
    void selectPage(int position);
}
