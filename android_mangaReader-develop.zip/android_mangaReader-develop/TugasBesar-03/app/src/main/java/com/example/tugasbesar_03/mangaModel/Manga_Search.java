package com.example.tugasbesar_03.mangaModel;

public class Manga_Search {
    protected String mangaTitle;
    protected String mangaID;
    protected String mangaIMG;

    public Manga_Search() {
    }

    public String getMangaTitle() {
        return mangaTitle;
    }

    public void setMangaTitle(String mangaTitle) {
        this.mangaTitle = mangaTitle;
    }

    public String getMangaID() {
        return mangaID;
    }

    public void setMangaID(String mangaID) {
        this.mangaID = mangaID;
    }

    public String getMangaIMG() {
        return mangaIMG;
    }

    public void setMangaIMG(String mangaIMG) {
        this.mangaIMG = mangaIMG;
    }
}
