package com.example.tugasbesar_03.view.pinchToZoom;

public interface OnPageSelectedListener {
    void selectedPage(int position);
}
