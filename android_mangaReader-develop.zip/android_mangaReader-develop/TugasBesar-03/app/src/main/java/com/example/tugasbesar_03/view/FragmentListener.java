package com.example.tugasbesar_03.view;


public interface FragmentListener {
    void onClick(boolean status);
}
