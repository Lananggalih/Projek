# Android Apps: Manga Reader with MangaEden API service

Hi all, this is my 3rd android apps which includes all things needed to make a manga-reader apps!

This apps used an API for manga-receiving which is a mangaeden's API services.

Feel free to contribute, and/or issuing a problem, thanks!
