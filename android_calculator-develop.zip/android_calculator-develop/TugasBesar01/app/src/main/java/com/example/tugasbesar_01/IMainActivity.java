/*
    created by:
        - 2016730035 Lanang Galih Saputro
        - 2016730040 Frederick
        - 2016730045 Reynaldi Irfan Anwar
 */
package com.example.tugasbesar_01;

import java.util.List;

public interface IMainActivity {
    public void updateList(List<Numop> num);
    public void resetAddForm();
}