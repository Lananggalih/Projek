# Android Apps: Simple Calculator

Hi, this is my first android apps. 

I made a simple calculator here, feel free to help or improving the code, thanks!
