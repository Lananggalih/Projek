# Android Apps: Airplane Games

Hi, i made this android apps that looks-like a Flappy Bird, and plays like Flappy Bird. 

The goal is to bring the plane not to crash with another objects, and get more scores by obtaining the gift objects.

Feel free to suggest new changes, and edit issue a problem, thanks!
