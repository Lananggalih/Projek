package com.example.tugasbesar_02;

public interface FragmentListener {
    void closeApp();

    void updateScore(String score);
}


